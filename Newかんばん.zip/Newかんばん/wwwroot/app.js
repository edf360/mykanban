// APIベースURL
const API_BASE = '/api/tickets';

// APIヘルパー関数
async function apiRequest(method, url, body) {
    const options = {
        method,
        headers: { 'Content-Type': 'application/json' },
    };
    if (body) {
        options.body = JSON.stringify(body);
    }
    const response = await fetch(url, options);
    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'API request failed');
    }
    if (response.status === 204) {
        return;
    }
    return response.json();
}

document.addEventListener('DOMContentLoaded', async () => {
    let ticketCounter = 0;
    let draggedTicket = null;

    // モーダル関連の変数
    let currentLabels = [];
    let currentAssignees = [];
    let currentChildTasks = [];
    let editingTicketId = null;
    let currentTicketData = {};
    let allTickets = [];
    let labelSuggestions = [];
    let assigneeSuggestions = [];

    // サーバーからチケット一覧を取得して表示
    async function loadTickets() {
        try {
            allTickets = await apiRequest('GET', API_BASE, null);
            currentTicketData = {};
            allTickets.forEach(ticket => {
                currentTicketData[ticket.ticketId] = ticket;
                if (parseInt(ticket.id) > ticketCounter) {
                    ticketCounter = parseInt(ticket.id);
                }
            });
            renderAllTickets();
        } catch (error) {
            console.error('Failed to load tickets:', error);
        }
    }

    // サジェストデータをロード
    async function loadSuggestions() {
        try {
            labelSuggestions = await apiRequest('GET', `${API_BASE}/labels/suggest`, null);
            assigneeSuggestions = await apiRequest('GET', `${API_BASE}/assignees/suggest`, null);
            populateAssigneeFilter();
        } catch (error) {
            console.error('Failed to load suggestions:', error);
        }
    }

    // 担当者フィルターをpopulate
    function populateAssigneeFilter() {
        const select = document.getElementById('assigneeSelect');
        if (!select) return;
        select.innerHTML = '<option value="">すべて</option>';
        assigneeSuggestions.forEach(assignee => {
            const option = document.createElement('option');
            option.value = assignee;
            option.textContent = assignee;
            select.appendChild(option);
        });
    }

    // 現在選択されているフィルター値を取得
    function getSelectedAssignee() {
        const select = document.getElementById('assigneeSelect');
        return select ? select.value : '';
    }

    // チケットがフィルター条件に一致するかチェック
    function ticketMatchesFilter(ticket) {
        const selectedAssignee = getSelectedAssignee();
        if (!selectedAssignee) return true; // フィルターなし=すべて表示
        return ticket.assignees && ticket.assignees.includes(selectedAssignee);
    }

    function renderAllTickets() {
        // 各カラムのticket-listをクリア
        document.querySelectorAll('.ticket-list').forEach(list => {
            list.innerHTML = '';
        });
        
        allTickets.forEach(ticket => {
            // フィルター条件に一致しないチケットはスキップ
            if (!ticketMatchesFilter(ticket)) return;
            
            // アーカイブ済みのチケットはArchiveカラムに配置
            if (ticket.isArchived) {
                const archiveList = document.querySelector('#archiveColumn .ticket-list');
                if (archiveList) {
                    const ticketEl = createTicketElement(ticket);
                    archiveList.appendChild(ticketEl);
                }
            } else {
                // 通常カラムに配置
                const columnEl = document.querySelector(`.column[data-column="${ticket.column}"] .ticket-list`);
                if (columnEl) {
                    const ticketEl = createTicketElement(ticket);
                    columnEl.appendChild(ticketEl);
                }
            }
        });
        
        // カラムカウントを更新（メモカラムは除外）
        document.querySelectorAll('.column:not([data-column="memo"])').forEach(updateColumnCount);
    }

    function createTicketElement(data) {
        const ticket = document.createElement('div');
        ticket.className = 'ticket';
        ticket.draggable = true; // アーカイブでもドラッグ可能（他のカラムへ移動）
        ticket.dataset.id = data.ticketId;
        currentTicketData[data.ticketId] = data;

        const titleHtml = data.title ? escapeHtml(data.title) : '(タイトルなし)';
        
        // 上部にラベルと担当者を表示
        let topInfoHtml = '';
        if ((data.labels && data.labels.length > 0) || (data.assignees && data.assignees.length > 0)) {
            topInfoHtml = '<div class="ticket-top-info">';
            if (data.labels && data.labels.length > 0) {
                topInfoHtml += '<div class="ticket-labels">';
                data.labels.forEach(label => {
                    topInfoHtml += `<span class="ticket-label">${escapeHtml(label)}</span>`;
                });
                topInfoHtml += '</div>';
            }
            if (data.assignees && data.assignees.length > 0) {
                topInfoHtml += '<div class="ticket-assignees">';
                data.assignees.forEach((assignee, idx) => {
                    const mainClass = idx === 0 ? ' main' : '';
                    const crownIcon = idx === 0 ? '👑 ' : '';
                    topInfoHtml += `<span class="ticket-assignee${mainClass}">${crownIcon}${escapeHtml(assignee)}</span>`;
                });
                topInfoHtml += '</div>';
            }
            topInfoHtml += '</div>';
        }

        let detailsHtml = '';

        // 子タスクをチケットに表示
        let childTasksHtml = '';
        if (data.childTasks.length > 0) {
            childTasksHtml = '<div class="ticket-child-tasks">';
            data.childTasks.forEach((task, i) => {
                const doneClass = task.done ? ' done' : '';
                childTasksHtml += `
                    <div class="ticket-child-task-item${doneClass}" data-child-index="${i}">
                        <input type="checkbox" ${task.done ? 'checked' : ''} data-child-check="${i}">
                        <span class="ticket-child-task-text">${escapeHtml(task.text)}</span>
                    </div>`;
            });
            childTasksHtml += '</div>';
        }

        // グラフを表示（開始日と終了日がある場合）
        let chartHtml = '';
        if (data.startDate && data.endDate) {
            chartHtml = `<div class="ticket-chart" data-start="${data.startDate}" data-end="${data.endDate}"></div>`;
        }

        // 工数バッジ（タイトルの右側）
        let effortBadge = '';
        if (data.effort) {
            effortBadge = `<span class="ticket-effort">${data.effort}h</span>`;
        }

        ticket.innerHTML = `
            ${topInfoHtml}
            <div class="ticket-title-row">
                <div class="ticket-content">${titleHtml}</div>
                ${effortBadge}
            </div>
            ${childTasksHtml}
            ${chartHtml}
            <div class="progress-container">
                <span class="progress-label">進捗:</span>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${data.progress || 0}%"></div>
                </div>
                <span class="progress-text">${data.progress || 0}%</span>
            </div>
            <button class="delete-btn">&times;</button>
        `;

        ticket.addEventListener('dragstart', handleDragStart);
        ticket.addEventListener('dragend', handleDragEnd);
        
        // チケットクリックでモーダルを開く（子タスクのチェックボックスは除外）
        // アーカイブされたチケットは編集ダイアログを出さない
        ticket.addEventListener('click', (e) => {
            // 削除ボタン、プログレスバー、子タスクのチェックボックス、ドラッグ直後は除外
            if (e.target.classList.contains('delete-btn') || e.target.closest('.progress-bar') || e.target.closest('[data-child-check]')) return;
            if (wasProgressDragging) return;
            // アーカイブ済みチケットは編集ダイアログを開かない
            if (data.isArchived) return;
            openEditModal(ticket.dataset.id);
        });

        // 子タスクのチェックボックスイベント
        const childCheckboxes = ticket.querySelectorAll('[data-child-check]');
        childCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', async (e) => {
                e.stopPropagation();
                const index = parseInt(checkbox.dataset.childCheck);
                try {
                    const updated = await apiRequest('PATCH', `${API_BASE}/${ticket.dataset.id}/child-task/${index}`, { done: checkbox.checked });
                    currentTicketData[ticket.dataset.id] = updated;
                    // 全チケットを更新
                    const idx = allTickets.findIndex(t => t.ticketId === ticket.dataset.id);
                    if (idx !== -1) allTickets[idx] = updated;
                } catch (error) {
                    console.error('Failed to update child task:', error);
                    checkbox.checked = !checkbox.checked;
                }
                
                const item = checkbox.closest('.ticket-child-task-item');
                if (checkbox.checked) {
                    item.classList.add('done');
                } else {
                    item.classList.remove('done');
                }
            });
        });

        // グラフを描画
        const chartEl = ticket.querySelector('.ticket-chart');
        if (chartEl) {
            renderProgressChart(chartEl, data.startDate, data.endDate);
        }
        
        const progressBar = ticket.querySelector('.progress-bar');
        const progressFill = ticket.querySelector('.progress-fill');
        const progressText = ticket.querySelector('.progress-text');
        
        let isDragging = false;
        let wasProgressDragging = false;
        
        const updateProgress = (clientX) => {
            const rect = progressBar.getBoundingClientRect();
            let percentage = ((clientX - rect.left) / rect.width) * 100;
            percentage = Math.max(0, Math.min(100, Math.round(percentage / 10) * 10));
            progressFill.style.width = `${percentage}%`;
            progressText.textContent = `${percentage}%`;
        };
        
        progressBar.addEventListener('mousedown', (e) => {
            e.stopPropagation();
            e.preventDefault();
            isDragging = true;
            wasProgressDragging = false;
            updateProgress(e.clientX);
            
            ticket.draggable = false;
        });
        
        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                e.preventDefault();
                wasProgressDragging = true;
                updateProgress(e.clientX);
            }
        });
        
        document.addEventListener('mouseup', async (e) => {
            if (isDragging) {
                isDragging = false;
                ticket.draggable = true;
                
                // マウスを離したタイミングで進捗を確定し、サーバーに保存
                const percentage = parseInt(progressText.textContent);
                
                try {
                    await apiRequest('PATCH', `${API_BASE}/${ticket.dataset.id}/progress`, { progress: percentage });
                    
                    const currentColumn = ticket.closest('.column');
                    const targetColumn = percentage === 100 ? 'done' : (percentage >= 10 && percentage <= 90 ? 'doing' : null);
                    
                    if (targetColumn && currentColumn.dataset.column !== targetColumn) {
                        await apiRequest('PATCH', `${API_BASE}/${ticket.dataset.id}/column`, { column: targetColumn });
                        const targetList = document.querySelector(`.column[data-column="${targetColumn}"] .ticket-list`);
                        targetList.appendChild(ticket);
                        updateColumnCount(currentColumn);
                        updateColumnCount(document.querySelector(`.column[data-column="${targetColumn}"]`));
                        
                        // データを更新
                        const idx = allTickets.findIndex(t => t.ticketId === ticket.dataset.id);
                        if (idx !== -1) allTickets[idx].column = targetColumn;
                    }
                    
                    // 進捗データを更新
                    const idx2 = allTickets.findIndex(t => t.ticketId === ticket.dataset.id);
                    if (idx2 !== -1) allTickets[idx2].progress = percentage;
                } catch (error) {
                    console.error('Failed to update progress:', error);
                }
                
                // グラフを更新
                const chartEl = ticket.querySelector('.ticket-chart');
                if (chartEl) {
                    const data = currentTicketData[ticket.dataset.id];
                    if (data && data.startDate && data.endDate) {
                        renderProgressChart(chartEl, data.startDate, data.endDate);
                    }
                }
                
                // クリックイベントを抑制するために少し待ってからフラグをリセット
                setTimeout(() => {
                    wasProgressDragging = false;
                }, 100);
            }
        });
        
        const deleteBtn = ticket.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const ticketData = currentTicketData[ticket.dataset.id];
            const isArchived = ticketData && ticketData.isArchived;
            
            // アーカイブ内のチケットの場合は完全削除の確認
            if (isArchived) {
                if (!confirm('このチケットを完全に削除しますか？')) {
                    return;
                }
            }
            
            try {
                await apiRequest('DELETE', `${API_BASE}/${ticket.dataset.id}`, null);
                await loadTickets(); // 再読み込みでアーカイブ移動または完全削除を反映
            } catch (error) {
                console.error('Failed to delete ticket:', error);
            }
        });

        return ticket;
    }

    function startEdit(element) {
        element.contentEditable = true;
        element.focus();
        
        const range = document.createRange();
        range.selectNodeContents(element);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        
        const finishEdit = () => {
            element.contentEditable = false;
            if (element.textContent.trim() === '') {
                element.closest('.ticket').remove();
                const column = element.closest('.column');
                updateColumnCount(column);
            }
            element.removeEventListener('blur', finishEdit);
            element.removeEventListener('keydown', handleKeyDown);
        };
        
        const handleKeyDown = (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                element.blur();
            } else if (e.key === 'Escape') {
                element.textContent = element.dataset.originalText;
                element.blur();
            }
        };
        
        element.dataset.originalText = element.textContent;
        element.addEventListener('blur', finishEdit);
        element.addEventListener('keydown', handleKeyDown);
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // 日付を「月(月)」形式に変換する関数
    function formatDateWithDay(date) {
        const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
        const days = ['日', '月', '火', '水', '木', '金', '土'];
        const month = months[date.getMonth()];
        const day = date.getDate();
        const weekday = days[date.getDay()];
        return `${month}${day}(${weekday})`;
    }

    // 進捗グラフを描画する関数
    function renderProgressChart(container, startDate, endDate) {
        const width = 260;
        const height = 50;
        const labelHeight = 18;
        const padding = { top: 5, right: 20, bottom: 5, left: 20 };
        
        const start = new Date(startDate);
        const end = new Date(endDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // グラフの右端は終了日と本日のうち遅い方
        const graphEnd = today > end ? today : end;
        
        // 今日が終了日以降の場合は進捗率を取得
        let currentProgress = 0;
        const ticketId = container.closest('.ticket')?.dataset.id;
        if (ticketId) {
            const data = currentTicketData[ticketId];
            if (data) {
                const progressText = container.closest('.ticket').querySelector('.progress-text');
                if (progressText) {
                    currentProgress = parseInt(progressText.textContent) || 0;
                }
            }
        }
        
        // グラフの描画領域
        const graphWidth = width - padding.left - padding.right;
        const graphHeight = height - padding.top - padding.bottom;
        
        // 座標計算（graphEndを使用）
        const xScale = (date) => {
            const time = date.getTime();
            const startTime = start.getTime();
            const graphEndTime = graphEnd.getTime();
            if (graphEndTime === startTime) return 0;
            return ((time - startTime) / (graphEndTime - startTime)) * graphWidth + padding.left;
        };
        
        const yScale = (progress) => {
            return graphHeight - (progress / 100) * graphHeight + padding.top;
        };
        
        // 予定線: 開始日(0%) → 終了日(100%) — 青線
        const plannedLine = `
            <line
                x1="${xScale(start)}" y1="${yScale(0)}"
                x2="${xScale(end)}" y2="${yScale(100)}"
                stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4,4"
            />
        `;
        
        // 実績線: 開始日(0%) → 今日(現在の進捗率) — 赤線
        // 完了日を過ぎている場合はグラフの右端に接続
        let actualLine = '';
        if (today >= start) {
            const actualEndX = today > end ? width - padding.right : xScale(today);
            const actualEndY = yScale(currentProgress);
            actualLine = `
                <line
                    x1="${xScale(start)}" y1="${yScale(0)}"
                    x2="${actualEndX}" y2="${actualEndY}"
                    stroke="#ef4444" stroke-width="1.5"
                />
                <circle cx="${actualEndX}" cy="${actualEndY}" r="3" fill="#ef4444"/>
            `;
        }
        
        // グリッド線（0%、25%、50%、75%、100%）
        const gridLines = `
            <line x1="${padding.left}" y1="${yScale(0)}" x2="${width - padding.right}" y2="${yScale(0)}" stroke="#d1d5db" stroke-width="0.5"/>
            <line x1="${padding.left}" y1="${yScale(25)}" x2="${width - padding.right}" y2="${yScale(25)}" stroke="#e5e7eb" stroke-width="0.5"/>
            <line x1="${padding.left}" y1="${yScale(50)}" x2="${width - padding.right}" y2="${yScale(50)}" stroke="#e5e7eb" stroke-width="0.5"/>
            <line x1="${padding.left}" y1="${yScale(75)}" x2="${width - padding.right}" y2="${yScale(75)}" stroke="#e5e7eb" stroke-width="0.5"/>
            <line x1="${padding.left}" y1="${yScale(100)}" x2="${width - padding.right}" y2="${yScale(100)}" stroke="#d1d5db" stroke-width="0.5"/>
        `;
        
        // 日付ラベル（グラフの左右端に中央揃え）
        const startDateLabel = formatDateWithDay(start);
        const rightDateLabel = today > end ? formatDateWithDay(today) : formatDateWithDay(end);
        const dateLabels = `
            <text x="${padding.left}" y="${height + labelHeight - 2}" font-size="12" fill="#6b7280" text-anchor="middle">${startDateLabel}</text>
            <text x="${width - padding.right}" y="${height + labelHeight - 2}" font-size="12" fill="#6b7280" text-anchor="middle">${rightDateLabel}</text>
        `;
        
        // SVG生成（日付ラベル分の高さを追加）
        container.innerHTML = `
            <svg viewBox="0 0 ${width} ${height + labelHeight}" xmlns="http://www.w3.org/2000/svg">
                ${gridLines}
                ${plannedLine}
                ${actualLine}
                ${dateLabels}
            </svg>
        `;
    }

    // 担当者の全チケットから累積予実グラフを描画する関数
    function renderAssigneeChart(container, assigneeName) {
        const width = 400;
        const height = 180;
        const padding = { top: 10, right: 20, bottom: 25, left: 40 };
        
        // この担当者のチケットをフィルタ（アーカイブ除外）
        const assigneeTickets = allTickets.filter(t =>
            t.assignees && t.assignees.includes(assigneeName)
            && t.startDate && t.endDate
            && !t.isArchived
        );
        
        if (assigneeTickets.length === 0) {
            container.innerHTML = '<div style="text-align:center;color:#9ca3af;padding:20px;font-size:12px;">データがありません</div>';
            return;
        }
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // 全チケットの開始日・終了日からグラフの範囲を計算
        let minDate = new Date(assigneeTickets[0].startDate);
        let maxDate = new Date(assigneeTickets[0].endDate);
        
        assigneeTickets.forEach(t => {
            const s = new Date(t.startDate);
            const e = new Date(t.endDate);
            if (s < minDate) minDate = s;
            if (e > maxDate) maxDate = e;
        });
        
        // グラフの右端は最終終了日と本日のうち遅い方
        const graphEnd = today > maxDate ? today : maxDate;
        
        const graphWidth = width - padding.left - padding.right;
        const graphHeight = height - padding.top - padding.bottom;
        
        // 日付 → X座標
        const xScale = (date) => {
            const time = date.getTime();
            const startTime = minDate.getTime();
            const endTime = graphEnd.getTime();
            if (endTime === startTime) return 0;
            return ((time - startTime) / (endTime - startTime)) * graphWidth + padding.left;
        };
        
        // 各日付の累積予定工数・実績工数を計算
        const days = [];
        const current = new Date(minDate);
        while (current <= graphEnd) {
            days.push(new Date(current));
            current.setDate(current.getDate() + 1);
        }
        
        // 予定累積工数: 各チケットは開始日〜終了日に均等に工数を分配
        const plannedCumulative = [];
        const actualCumulative = [];
        let totalPlanned = 0;
        let totalActual = 0;
        
        days.forEach(day => {
            assigneeTickets.forEach(ticket => {
                const start = new Date(ticket.startDate);
                const end = new Date(ticket.endDate);
                const effort = ticket.effort || 0;
                
                // この日がチケットの期間内か？
                if (day >= start && day <= end) {
                    // 期間の日数（開始日〜終了日を含まない）
                    const durationDays = Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);
                    const dailyEffort = effort / durationDays;
                    totalPlanned += dailyEffort;
                }
                
                // 実績: 今日以前で、進捗率に応じて分配
                if (day <= today && day >= start) {
                    const progress = ticket.progress || 0;
                    const actualEffort = effort * (progress / 100);
                    // 実績は開始日から今日まで均等に（簡易計算）
                    const daysFromStart = Math.round((day - start) / (1000 * 60 * 60 * 24));
                    const totalDays = Math.max(1, daysFromStart + 1);
                    if (daysFromStart >= 0) {
                        totalActual += actualEffort / totalDays;
                    }
                }
            });
            
            plannedCumulative.push(totalPlanned);
            actualCumulative.push(Math.min(totalActual, totalPlanned));
        });
        
        // Y軸の最大値（予定の最大値を基準に10%余裕）
        const maxEffort = Math.max(...plannedCumulative, 1);
        const yMax = Math.ceil(maxEffort * 1.1 / 5) * 5; // 5で割って切り上げ
        
        const yScale = (value) => {
            return graphHeight - (value / yMax) * graphHeight + padding.top;
        };
        
        // 予定線（青色点線）を生成
        let plannedPath = '';
        days.forEach((day, i) => {
            const x = xScale(day);
            const y = yScale(plannedCumulative[i]);
            if (i === 0) {
                plannedPath += `M ${x} ${y}`;
            } else {
                plannedPath += ` L ${x} ${y}`;
            }
        });
        
        // 実績線（赤色実線）を生成
        let actualPath = '';
        days.forEach((day, i) => {
            const x = xScale(day);
            const y = yScale(actualCumulative[i]);
            if (i === 0) {
                actualPath += `M ${x} ${y}`;
            } else {
                actualPath += ` L ${x} ${y}`;
            }
        });
        
        // Y軸グリッド線とラベル
        const gridSteps = 5;
        let gridLines = '';
        let yLabels = '';
        for (let i = 0; i <= gridSteps; i++) {
            const value = (yMax / gridSteps) * i;
            const y = yScale(value);
            gridLines += `<line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="#e5e7eb" stroke-width="0.5"/>`;
            yLabels += `<text x="${padding.left - 6}" y="${y + 4}" font-size="10" fill="#9ca3af" text-anchor="end">${Math.round(value)}</text>`;
        }
        
        // X軸日付ラベル（適宜間引く）
        let xLabels = '';
        const labelInterval = Math.max(1, Math.floor(days.length / 6));
        days.forEach((day, i) => {
            if (i % labelInterval === 0 || i === days.length - 1) {
                const x = xScale(day);
                const label = `${day.getMonth() + 1}/${day.getDate()}`;
                xLabels += `<text x="${x}" y="${height - 4}" font-size="10" fill="#9ca3af" text-anchor="middle">${label}</text>`;
            }
        });
        
        // 今日のマーカー
        let todayMarker = '';
        if (today >= minDate && today <= graphEnd) {
            const todayX = xScale(today);
            todayMarker = `<line x1="${todayX}" y1="${padding.top}" x2="${todayX}" y2="${graphHeight + padding.top}" stroke="#f59e0b" stroke-width="1" stroke-dasharray="3,3"/>`;
        }
        
        container.innerHTML = `
            <svg viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
                ${gridLines}
                ${yLabels}
                ${xLabels}
                ${todayMarker}
                <path d="${plannedPath}" fill="none" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4,4"/>
                <path d="${actualPath}" fill="none" stroke="#ef4444" stroke-width="1.5"/>
            </svg>
        `;
    }

    function handleDragStart(e) {
        draggedTicket = this;
        this.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', this.dataset.id);
        
        removeDropIndicators();
    }

    function handleDragEnd(e) {
        this.classList.remove('dragging');
        draggedTicket = null;
        
        document.querySelectorAll('.ticket-list').forEach(list => {
            list.classList.remove('drag-over');
        });
    }

    function removeDropIndicators() {
        document.querySelectorAll('.drop-indicator').forEach(indicator => {
            indicator.remove();
        });
    }

    function setupDropZones() {
        const ticketLists = document.querySelectorAll('.ticket-list');
        
        ticketLists.forEach(list => {
            list.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                
                removeDropIndicators();
                
                const tickets = Array.from(list.querySelectorAll('.ticket:not(.dragging)'));
                const listRect = list.getBoundingClientRect();
                
                let insertIndex = -1;
                for (let i = 0; i < tickets.length; i++) {
                    const ticketRect = tickets[i].getBoundingClientRect();
                    const midY = ticketRect.top + ticketRect.height / 2;
                    if (e.clientY < midY) {
                        insertIndex = i;
                        break;
                    }
                }
                
                const indicator = document.createElement('div');
                indicator.className = 'drop-indicator';
                
                let topPosition;
                if (insertIndex === -1 || insertIndex >= tickets.length) {
                    const lastTicket = tickets[tickets.length - 1];
                    if (lastTicket) {
                        const lastRect = lastTicket.getBoundingClientRect();
                        topPosition = lastRect.bottom - listRect.top + 6;
                    } else {
                        topPosition = 16;
                    }
                } else {
                    const ticketRect = tickets[insertIndex].getBoundingClientRect();
                    topPosition = ticketRect.top - listRect.top - 6;
                }
                
                indicator.style.top = `${topPosition}px`;
                list.appendChild(indicator);
            });

            list.addEventListener('dragleave', () => {
                removeDropIndicators();
            });

            list.addEventListener('drop', async (e) => {
                e.preventDefault();
                removeDropIndicators();
                
                if (draggedTicket) {
                    const tickets = Array.from(list.querySelectorAll('.ticket:not(.dragging)'));
                    
                    let insertIndex = -1;
                    for (let i = 0; i < tickets.length; i++) {
                        const ticketRect = tickets[i].getBoundingClientRect();
                        const midY = ticketRect.top + ticketRect.height / 2;
                        if (e.clientY < midY) {
                            insertIndex = i;
                            break;
                        }
                    }
                    
                    if (insertIndex === -1 || insertIndex > tickets.length - 1) {
                        const lastTicket = tickets[tickets.length - 1];
                        if (lastTicket) {
                            list.insertBefore(draggedTicket, lastTicket.nextSibling);
                        } else {
                            list.appendChild(draggedTicket);
                        }
                    } else {
                        list.insertBefore(draggedTicket, tickets[insertIndex]);
                    }
                    
                    const column = list.closest('.column');
                    updateColumnCount(column);
                    
                    // サーバーにカラム変更を通知
                    const newColumn = column.dataset.column;
                    const ticketId = draggedTicket.dataset.id;
                    try {
                        // 計算されたpositionを取得
                        const ticketsInColumn = Array.from(column.querySelectorAll('.ticket'));
                        const newPosition = ticketsInColumn.indexOf(draggedTicket);
                        
                        // アーカイブ状態を更新（archive外へ移動したらunarchive、archiveへ移動したらarchive）
                        const idx = allTickets.findIndex(t => t.ticketId === ticketId);
                        if (idx !== -1) {
                            const wasArchived = allTickets[idx].isArchived;
                            const isNowArchived = newColumn === 'archive';
                            
                            // archiveから外へ移動したらrestore APIを呼び出し
                            if (wasArchived && !isNowArchived) {
                                await apiRequest('PATCH', `${API_BASE}/${ticketId}/restore`, null);
                                allTickets[idx].isArchived = false;
                            } else if (!wasArchived && isNowArchived) {
                                // archiveへ移動したらarchive処理（DELETE APIを呼び出し）
                                await apiRequest('DELETE', `${API_BASE}/${ticketId}`, null);
                                allTickets[idx].isArchived = true;
                            }
                            
                            allTickets[idx].column = newColumn;
                        }
                        
                        await apiRequest('PATCH', `${API_BASE}/${ticketId}/column`, { column: newColumn, position: newPosition });
                    } catch (error) {
                        console.error('Failed to update column:', error);
                    }
                }
            });
        });
    }

    // モーダル操作
    function openNewModal() {
        editingTicketId = null;
        currentLabels = [];
        currentChildTasks = [];
        
        // フィルターで選択された担当者をデフォルトに設定
        const selectedAssignee = getSelectedAssignee();
        currentAssignees = selectedAssignee ? [selectedAssignee] : [];
        
        document.getElementById('modalTitle').textContent = '新しいチケット';
        document.getElementById('ticketTitle').value = '';
        document.getElementById('startDate').value = '';
        document.getElementById('endDate').value = '';
        document.getElementById('effort').value = '';
        document.getElementById('memo').value = '';
        document.getElementById('labelTags').innerHTML = '';
        document.getElementById('assigneeTags').innerHTML = '';
        document.getElementById('childTasks').innerHTML = '';
        
        // 担当者タグを表示（renderAssigneeTagsで統一）
        
        document.getElementById('ticketModal').classList.add('active');
    }

    function openEditModal(ticketId) {
        editingTicketId = ticketId;
        const data = currentTicketData[ticketId];
        if (!data) return;
        
        currentLabels = [...data.labels];
        currentAssignees = data.assignees ? [...data.assignees] : [];
        currentChildTasks = data.childTasks.map(t => ({...t}));
        
        document.getElementById('modalTitle').textContent = 'チケットを編集';
        document.getElementById('ticketTitle').value = data.title || '';
        document.getElementById('startDate').value = data.startDate ? data.startDate.substring(0, 10) : '';
        document.getElementById('endDate').value = data.endDate ? data.endDate.substring(0, 10) : '';
        document.getElementById('effort').value = data.effort || '';
        document.getElementById('memo').value = data.memo || '';
        
        // ラベル表示
        const labelTagsEl = document.getElementById('labelTags');
        labelTagsEl.innerHTML = '';
        currentLabels.forEach((label, i) => {
            labelTagsEl.innerHTML += `<span class="label-tag">${escapeHtml(label)} <span class="remove-label" data-index="${i}">&times;</span></span>`;
        });
        
        // 担当者表示（renderAssigneeTagsで統一）
        
        // 子タスク表示
        const childTasksEl = document.getElementById('childTasks');
        childTasksEl.innerHTML = '';
        currentChildTasks.forEach((task, i) => {
            addChildTaskToDom(task.text, task.done, i);
        });
        
        document.getElementById('ticketModal').classList.add('active');
    }

    function closeModal() {
        document.getElementById('ticketModal').classList.remove('active');
    }

    async function saveTicket() {
        const title = document.getElementById('ticketTitle').value.trim();
        const startDateVal = document.getElementById('startDate').value;
        const endDateVal = document.getElementById('endDate').value;
        const data = {
            title,
            startDate: startDateVal || null,
            endDate: endDateVal || null,
            effort: parseInt(document.getElementById('effort').value) || null,
            assignees: [...currentAssignees],
            labels: [...currentLabels],
            memo: document.getElementById('memo').value.trim(),
            childTasks: currentChildTasks.map(t => ({...t}))
        };
        
        try {
            if (editingTicketId) {
                // 既存チケットの更新
                const updated = await apiRequest('PUT', `${API_BASE}/${editingTicketId}`, data);
                currentTicketData[editingTicketId] = updated;
                
                // 配列も更新
                const idx = allTickets.findIndex(t => t.ticketId === editingTicketId);
                if (idx !== -1) allTickets[idx] = updated;
                
                const ticketEl = document.querySelector(`.ticket[data-id="${editingTicketId}"]`);
                if (ticketEl) {
                    const column = ticketEl.closest('.column');
                    recreateTicket(ticketEl, updated, column);
                }
            } else {
                // 新規作成 - todoカラムに追加
                data.column = 'todo';
                const created = await apiRequest('POST', API_BASE, data);
                currentTicketData[created.ticketId] = created;
                allTickets.push(created);
                
                const todoList = document.querySelector('.column[data-column="todo"] .ticket-list');
                const ticket = createTicketElement(created);
                todoList.appendChild(ticket);
                updateColumnCount(todoList.closest('.column'));
            }
        } catch (error) {
            console.error('Failed to save ticket:', error);
            alert('保存に失敗しました: ' + error.message);
            return;
        }
        
        closeModal();
    }

    function recreateTicket(ticketEl, data, column) {
        const oldId = ticketEl.dataset.id;
        const newTicket = createTicketElement(data);
        newTicket.dataset.id = oldId;
        currentTicketData[oldId] = data;
        
        // プログレスを維持
        const oldProgress = ticketEl.querySelector('.progress-text').textContent;
        const percentage = parseInt(oldProgress);
        const progressFill = newTicket.querySelector('.progress-fill');
        const progressText = newTicket.querySelector('.progress-text');
        progressFill.style.width = `${percentage}%`;
        progressText.textContent = `${percentage}%`;
        
        // グラフを更新（開始日と終了日がある場合）
        if (data.startDate && data.endDate) {
            const chartEl = newTicket.querySelector('.ticket-chart');
            if (chartEl) {
                renderProgressChart(chartEl, data.startDate, data.endDate);
            }
        }
        
        ticketEl.replaceWith(newTicket);
    }

    // ラベル操作
    function addLabel(text) {
        if (text.trim() && !currentLabels.includes(text.trim())) {
            currentLabels.push(text.trim());
            const labelTagsEl = document.getElementById('labelTags');
            const index = currentLabels.length - 1;
            labelTagsEl.innerHTML += `<span class="label-tag">${escapeHtml(text.trim())} <span class="remove-label" data-index="${index}">&times;</span></span>`;
        }
    }

    function removeLabel(index) {
        currentLabels.splice(index, 1);
        const labelTagsEl = document.getElementById('labelTags');
        labelTagsEl.innerHTML = '';
        currentLabels.forEach((label, i) => {
            labelTagsEl.innerHTML += `<span class="label-tag">${escapeHtml(label)} <span class="remove-label" data-index="${i}">&times;</span></span>`;
        });
    }

    // サジェスト表示関数
    function showSuggestions(suggestEl, suggestions, filter, callback) {
        let filtered = suggestions.filter(s => !callback.exclude.includes(s));
        
        // フィルタ文字がある場合はさらにフィルタリング
        if (filter) {
            filtered = filtered.filter(s => s.toLowerCase().includes(filter.toLowerCase()));
        }
        
        filtered = filtered.slice(0, 10);
        
        if (filtered.length > 0) {
            suggestEl.innerHTML = filtered.map(s =>
                `<div class="suggest-item">${escapeHtml(s)}</div>`
            ).join('');
            suggestEl.classList.add('active');
            
            suggestEl.querySelectorAll('.suggest-item').forEach(item => {
                item.addEventListener('click', () => {
                    callback.select(item.textContent);
                });
            });
        } else {
            suggestEl.classList.remove('active');
            suggestEl.innerHTML = '';
        }
    }

    // 担当者操作
    function addAssignee(text) {
        if (text.trim() && !currentAssignees.includes(text.trim())) {
            currentAssignees.push(text.trim());
            renderAssigneeTags();
        }
    }

    function removeAssignee(index) {
        currentAssignees.splice(index, 1);
        renderAssigneeTags();
    }

    // 担当者タグを再描画（メイン担当者に冠アイコン）
    function renderAssigneeTags() {
        const assigneeTagsEl = document.getElementById('assigneeTags');
        assigneeTagsEl.innerHTML = '';
        currentAssignees.forEach((assignee, i) => {
            const crownIcon = i === 0 ? '👑 ' : '';
            assigneeTagsEl.innerHTML += `<span class="assignee-tag">${crownIcon}${escapeHtml(assignee)} <span class="remove-assignee" data-index="${i}">&times;</span></span>`;
        });
    }

    // 担当者順番変更ダイアログ
    let orderModalAssignees = [];

    function openAssigneeOrderModal() {
        if (currentAssignees.length < 2) {
            alert('担当者が2人以上いる場合に順番を変更できます。');
            return;
        }
        orderModalAssignees = [...currentAssignees];
        renderAssigneeOrderList();
        document.getElementById('assigneeOrderModal').classList.add('active');
    }

    function closeAssigneeOrderModal() {
        document.getElementById('assigneeOrderModal').classList.remove('active');
    }

    function renderAssigneeOrderList() {
        const listEl = document.getElementById('assigneeOrderList');
        listEl.innerHTML = '';
        orderModalAssignees.forEach((assignee, i) => {
            const item = document.createElement('div');
            item.className = 'assignee-order-item' + (i === 0 ? ' main-assignee' : '');
            item.draggable = true;
            item.dataset.index = i;
            item.innerHTML = `
                <span class="assignee-order-drag-handle">⠿</span>
                ${i === 0 ? '<span class="assignee-order-crown">👑</span>' : ''}
                <span class="assignee-order-name">${escapeHtml(assignee)}</span>
            `;
            listEl.appendChild(item);

            item.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', i.toString());
                item.classList.add('dragging-order');
            });
            item.addEventListener('dragend', () => {
                item.classList.remove('dragging-order');
            });
            item.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
            });
            item.addEventListener('drop', (e) => {
                e.preventDefault();
                const fromIndex = parseInt(e.dataTransfer.getData('text/plain'));
                const toIndex = i;
                if (fromIndex !== toIndex) {
                    const moved = orderModalAssignees.splice(fromIndex, 1)[0];
                    orderModalAssignees.splice(toIndex, 0, moved);
                    renderAssigneeOrderList();
                }
            });
        });
    }

    async function saveAssigneeOrder() {
        if (!editingTicketId) return;
        try {
            const updated = await apiRequest('PATCH', `${API_BASE}/${editingTicketId}/assignees/order`, orderModalAssignees);
            currentAssignees = [...orderModalAssignees];
            const idx = allTickets.findIndex(t => t.ticketId === editingTicketId);
            if (idx !== -1) {
                allTickets[idx].assignees = [...orderModalAssignees];
            }
            currentTicketData[editingTicketId].assignees = [...orderModalAssignees];
            renderAssigneeTags();
            const ticketEl = document.querySelector(`.ticket[data-id="${editingTicketId}"]`);
            if (ticketEl) {
                const column = ticketEl.closest('.column');
                recreateTicket(ticketEl, currentTicketData[editingTicketId], column);
            }
        } catch (error) {
            console.error('Failed to update assignee order:', error);
            alert('順番の保存に失敗しました: ' + error.message);
        }
        closeAssigneeOrderModal();
    }

    // 子タスク操作
    function addChildTask(text, done = false, index = null) {
        const task = { text: text.trim(), done };
        if (index !== null) {
            currentChildTasks.splice(index, 1, task);
        } else {
            currentChildTasks.push(task);
        }
        renderChildTasks();
    }

    function removeChildTask(index) {
        currentChildTasks.splice(index, 1);
        renderChildTasks();
    }

    function addChildTaskToDom(text = '', done = false, index) {
        const childTasksEl = document.getElementById('childTasks');
        const div = document.createElement('div');
        div.className = 'child-task-item';
        div.dataset.index = index;
        div.innerHTML = `
            <input type="checkbox" ${done ? 'checked' : ''} data-child-index="${index}">
            <input type="text" value="${escapeHtml(text)}" placeholder="子タスク名" data-child-text="${index}">
            <button class="remove-child-task" data-remove-child="${index}">&times;</button>
        `;
        childTasksEl.appendChild(div);
        
        // イベント
        const checkbox = div.querySelector('input[type="checkbox"]');
        checkbox.addEventListener('change', () => {
            currentChildTasks[index].done = checkbox.checked;
        });
        
        const textInput = div.querySelector('input[type="text"]');
        textInput.addEventListener('input', () => {
            currentChildTasks[index].text = textInput.value;
        });
        
        const removeBtn = div.querySelector('.remove-child-task');
        removeBtn.addEventListener('click', () => {
            removeChildTask(index);
        });
    }

    function renderChildTasks() {
        const childTasksEl = document.getElementById('childTasks');
        childTasksEl.innerHTML = '';
        currentChildTasks.forEach((task, i) => {
            addChildTaskToDom(task.text, task.done, i);
        });
    }

    function updateColumnCount(column) {
        const countEl = column.querySelector('.column-count');
        if (!countEl) return; // メモカラムなどはスキップ
        const count = column.querySelectorAll('.ticket').length;
        countEl.textContent = `${count} 件`;
    }

    // イベントリスナー設定
    document.getElementById('cancelBtn').addEventListener('click', closeModal);
    document.getElementById('saveBtn').addEventListener('click', saveTicket);
    
    document.getElementById('ticketModal').addEventListener('click', (e) => {
        if (e.target.id === 'ticketModal') {
            saveTicket();
        }
    });

    // 履歴ダイアログ関連
    const historyModal = document.getElementById('historyModal');
    const viewHistoryBtn = document.getElementById('viewHistoryBtn');
    const closeHistoryBtn = document.getElementById('closeHistoryBtn');

    // 履歴を取得して表示
    async function showHistory(ticketId) {
        try {
            const histories = await apiRequest('GET', `${API_BASE}/${ticketId}/history`, null);
            const historyListEl = document.getElementById('historyList');
            
            if (!histories || histories.length === 0) {
                historyListEl.innerHTML = '<div class="history-empty">履歴はありません</div>';
            } else {
                historyListEl.innerHTML = '';
                // 日付順にグループ化（新しい日が先）
                const grouped = {};
                for (const h of histories) {
                    const dateKey = h.date.split('T')[0];
                    if (!grouped[dateKey]) grouped[dateKey] = [];
                    grouped[dateKey].push(h);
                }
                
                const typeLabels = {
                    created: '作成',
                    progress: '進捗',
                    column: '移動',
                    assignee: '担当者'
                };

                for (const [date, items] of Object.entries(grouped)) {
                    // 日付ヘッダー
                    const dateDiv = document.createElement('div');
                    dateDiv.className = 'history-date';
                    dateDiv.style.marginBottom = '4px';
                    dateDiv.style.marginTop = '8px';
                    dateDiv.style.fontWeight = '600';
                    dateDiv.textContent = date;
                    historyListEl.appendChild(dateDiv);
                    
                    for (const item of items) {
                        const div = document.createElement('div');
                        div.className = 'history-item';
                        
                        const typeLabel = typeLabels[item.type] || item.type;
                        let detail = '';
                        
                        if (item.type === 'created') {
                            detail = 'チケットが作成されました';
                        } else if (item.type === 'progress') {
                            detail = `進捗を ${item.previousValue ?? '-'}% → ${item.value}% に変更`;
                        } else if (item.type === 'column') {
                            const columnNames = { todo: 'To Do', doing: 'Doing', done: 'Done', archive: 'Archive' };
                            const from = columnNames[item.previousValue] || item.previousValue;
                            const to = columnNames[item.value] || item.value;
                            detail = `${from} → ${to} に移動`;
                        } else if (item.type === 'assignee') {
                            try {
                                const oldList = JSON.parse(item.previousValue || '[]');
                                const newList = JSON.parse(item.value || '[]');
                                detail = `担当者: [${oldList.join(', ')}] → [${newList.join(', ')}]`;
                            } catch {
                                detail = `担当者が変更されました`;
                            }
                        }
                        
                        div.innerHTML = `
                            <span class="history-type ${item.type}">${typeLabel}</span>
                            <span class="history-detail">${detail}</span>
                        `;
                        historyListEl.appendChild(div);
                    }
                }
            }
            
            historyModal.classList.add('active');
        } catch (error) {
            console.error('Failed to load history:', error);
            document.getElementById('historyList').innerHTML =
                '<div class="history-empty">履歴の読み込みに失敗しました</div>';
            historyModal.classList.add('active');
        }
    }

    viewHistoryBtn.addEventListener('click', () => {
        if (editingTicketId) {
            showHistory(editingTicketId);
        }
    });

    closeHistoryBtn.addEventListener('click', () => {
        historyModal.classList.remove('active');
    });

    historyModal.addEventListener('click', (e) => {
        if (e.target.id === 'historyModal') {
            historyModal.classList.remove('active');
        }
    });

    // ラベル入力（サジェスト付き）
    const labelInput = document.getElementById('labelInput');
    const labelSuggestEl = document.getElementById('labelSuggest');

    // フォーカス時に全選択肢を表示
    labelInput.addEventListener('focus', () => {
        showSuggestions(labelSuggestEl, labelSuggestions, '', {
            exclude: currentLabels,
            select: (text) => {
                addLabel(text);
                labelInput.value = '';
                hideSuggestion(labelSuggestEl);
            }
        });
    });

    // 入力時にフィルタリング
    labelInput.addEventListener('input', () => {
        const val = labelInput.value.trim();
        showSuggestions(labelSuggestEl, labelSuggestions, val, {
            exclude: currentLabels,
            select: (text) => {
                addLabel(text);
                labelInput.value = '';
                hideSuggestion(labelSuggestEl);
            }
        });
    });

    labelInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const val = e.target.value.trim();
            if (val) {
                addLabel(val);
                e.target.value = '';
                hideSuggestion(labelSuggestEl);
            }
        }
    });

    // ラベル削除（イベントデリゲーション）
    document.getElementById('labelTags').addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-label')) {
            const index = parseInt(e.target.dataset.index);
            removeLabel(index);
        }
    });

    // 担当者入力（サジェスト付き）
    const assigneeInput = document.getElementById('assigneeInput');
    const assigneeSuggestEl = document.getElementById('assigneeSuggest');

    // フォーカス時に全選択肢を表示
    assigneeInput.addEventListener('focus', () => {
        showSuggestions(assigneeSuggestEl, assigneeSuggestions, '', {
            exclude: currentAssignees,
            select: (text) => {
                addAssignee(text);
                assigneeInput.value = '';
                hideSuggestion(assigneeSuggestEl);
            }
        });
    });

    // 入力時にフィルタリング
    assigneeInput.addEventListener('input', () => {
        const val = assigneeInput.value.trim();
        showSuggestions(assigneeSuggestEl, assigneeSuggestions, val, {
            exclude: currentAssignees,
            select: (text) => {
                addAssignee(text);
                assigneeInput.value = '';
                hideSuggestion(assigneeSuggestEl);
            }
        });
    });

    assigneeInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const val = e.target.value.trim();
            if (val) {
                addAssignee(val);
                e.target.value = '';
                hideSuggestion(assigneeSuggestEl);
            }
        }
    });

    // 担当者削除（イベントデリゲーション）
    document.getElementById('assigneeTags').addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-assignee')) {
            const index = parseInt(e.target.dataset.index);
            removeAssignee(index);
        }
    });

    // サジェストを隠すヘルパー関数
    function hideSuggestion(el) {
        el.classList.remove('active');
        el.innerHTML = '';
    }

    // モーダル外クリックでサジェストを閉じる
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#labelInput') && !e.target.closest('#labelSuggest')) {
            hideSuggestion(labelSuggestEl);
        }
        if (!e.target.closest('#assigneeInput') && !e.target.closest('#assigneeSuggest')) {
            hideSuggestion(assigneeSuggestEl);
        }
    });

    // 子タスク追加ボタン
    document.getElementById('addChildTaskBtn').addEventListener('click', () => {
        addChildTask('', false);
    });

    // 担当者順番変更ダイアログのイベント
    document.getElementById('reorderAssigneesBtn').addEventListener('click', openAssigneeOrderModal);
    document.getElementById('closeAssigneeOrderBtn').addEventListener('click', closeAssigneeOrderModal);
    document.getElementById('saveAssigneeOrderBtn').addEventListener('click', saveAssigneeOrder);

    // Todo カラムの追加ボタン
    const addBtn = document.querySelector('.column[data-column="todo"] .add-ticket-btn');
    if (addBtn) {
        addBtn.addEventListener('click', openNewModal);
    }

        setupDropZones();
        
        // 画面左下のArchiveトグルボタン
        const archiveToggleBottomBtn = document.getElementById('archiveToggleBtn');
        const archiveColumn = document.getElementById('archiveColumn');
        
        if (archiveToggleBottomBtn && archiveColumn) {
            archiveToggleBottomBtn.addEventListener('click', () => {
                if (archiveColumn.style.display === 'none') {
                    archiveColumn.style.display = 'flex';
                } else {
                    archiveColumn.style.display = 'none';
                }
            });
        }
        
        // 担当者フィルター変更イベント
        const assigneeSelect = document.getElementById('assigneeSelect');
        const memoColumn = document.getElementById('memoColumn');
        const memoColumnTitle = document.getElementById('memoColumnTitle');
        const assigneeMemoText = document.getElementById('assigneeMemoText');

        // メモをLocalStorageから取得
        function getAssigneeMemo(assignee) {
            try {
                return localStorage.getItem(`assignee_memo_${assignee}`) || '';
            } catch (e) {
                return '';
            }
        }

        // メモをLocalStorageに保存
        function saveAssigneeMemo(assignee, memo) {
            try {
                localStorage.setItem(`assignee_memo_${assignee}`, memo);
            } catch (e) {
                console.error('Failed to save memo:', e);
            }
        }

        // 現在のフィルターのメモを表示/非表示
        function updateMemoColumn() {
            const selectedAssignee = getSelectedAssignee();
            if (!selectedAssignee) {
                memoColumn.style.display = 'none';
                return;
            }
            assigneeMemoText.value = getAssigneeMemo(selectedAssignee);
            memoColumnTitle.textContent = `${selectedAssignee} - Memo`;
            memoColumn.style.display = 'flex';
            // 予実グラフを描画
            const chartContainer = document.getElementById('assigneeChart');
            if (chartContainer) {
                renderAssigneeChart(chartContainer, selectedAssignee);
            }
        }

        // メモテキスト変更時に自動保存
        let memoSaveTimeout = null;
        assigneeMemoText.addEventListener('input', () => {
            const selectedAssignee = getSelectedAssignee();
            if (!selectedAssignee) return;
            clearTimeout(memoSaveTimeout);
            memoSaveTimeout = setTimeout(() => {
                saveAssigneeMemo(selectedAssignee, assigneeMemoText.value);
            }, 300);
        });

        if (assigneeSelect) {
            assigneeSelect.addEventListener('change', () => {
                renderAllTickets();
                updateMemoColumn();
            });
        }
        
        // サーバーからチケットをロード
        await loadTickets();
        
        // サジェストデータをロード
        await loadSuggestions();
        
        // 初期状態でメモカラムを更新（フィルターが設定されていれば表示）
        updateMemoColumn();
    });