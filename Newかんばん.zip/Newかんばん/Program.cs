using KanbanServer.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);

// SQLiteデータベース設定
builder.Services.AddDbContext<KanbanDbContext>(options =>
    options.UseSqlite("Data Source=kanban.db"));

// CORS設定
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// コントローラーとJSONシリアライザー設定
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.WriteIndented = true;
    });

var app = builder.Build();

// 1. CORSを有効化
app.UseCors("AllowAll");

// 2. SQLite DB自動作成
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<KanbanDbContext>();
    db.Database.EnsureCreated();
}

// 3. APIルートをマップ（/api/プレフィックスのみ）
app.MapControllers();

// 4. wwwrootからの静的ファイル配信
var wwwRootPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot");
if (Directory.Exists(wwwRootPath))
{
    app.UseStaticFiles(new StaticFileOptions
    {
        FileProvider = new PhysicalFileProvider(wwwRootPath),
        RequestPath = ""  // ルートから直接配信
    });
}

// 5. SPAフォールバック - API以外のすべてのリクエストでkanban.htmlを返す
app.MapFallback(async context =>
{
    var filePath = Path.Combine(wwwRootPath, "kanban.html");
    if (File.Exists(filePath))
    {
        context.Response.ContentType = "text/html; charset=utf-8";
        await context.Response.SendFileAsync(filePath);
    }
    else
    {
        context.Response.StatusCode = 404;
    }
});

app.Run();
